// Demo accounts for testing (remove in production)
const demoAccounts = {
    client: [
        { email: "client@klensecfarm.com", password: "client123", name: "Michael Client" },
        { email: "customer@example.com", password: "customer123", name: "Sarah Customer" }
    ],
    employee: [
        { id: "EMP001", password: "employee123", name: "Kwame Employee", department: "Field Operations" },
        { id: "EMP002", password: "employee456", name: "Ama Staff", department: "Logistics" }
    ],
    admin: [
        { username: "admin", password: "admin123", name: "System Administrator", role: "Super Admin" },
        { username: "manager", password: "manager123", name: "Operations Manager", role: "Manager" }
    ]
};

// Modal functionality
function openModal(portalType) {
    const modalElement = document.getElementById(portalType + 'Modal');
    if (modalElement) {
        modalElement.style.display = 'flex';
    }
}

function closeModal(modalId) {
    const modalElement = document.getElementById(modalId);
    if (modalElement) {
        modalElement.style.display = 'none';
        // Clear form fields when closing
        const form = modalElement.querySelector('form');
        if (form) form.reset();
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        closeModal(event.target.id);
    }
};

// Enhanced form submission with authentication
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const modal = this.closest('.modal');
        if (!modal) return;
        
        const portalType = modal.id.replace('Modal', '');
        
        if (authenticateUser(portalType, this)) {
            // Successful login
            showLoginSuccess(portalType);
            closeModal(modal.id);
        } else {
            // Failed login
            showLoginError(portalType);
        }
    });
});

// Authentication function
function authenticateUser(portalType, form) {
    switch(portalType) {
        case 'client':
            const clientEmail = document.getElementById('clientEmail');
            const clientPassword = document.getElementById('clientPassword');
            if (!clientEmail || !clientPassword) return false;
            
            const email = clientEmail.value;
            const password = clientPassword.value;
            
            return demoAccounts.client.some(account => 
                account.email === email && account.password === password
            );
            
        case 'employee':
            const employeeId = document.getElementById('employeeId');
            const employeePassword = document.getElementById('employeePassword');
            if (!employeeId || !employeePassword) return false;
            
            const empId = employeeId.value;
            const empPassword = employeePassword.value;
            
            return demoAccounts.employee.some(account => 
                account.id === empId && account.password === empPassword
            );
            
        case 'admin':
            const adminUsername = document.getElementById('adminUsername');
            const adminPassword = document.getElementById('adminPassword');
            if (!adminUsername || !adminPassword) return false;
            
            const username = adminUsername.value;
            const adminPass = adminPassword.value;
            
            return demoAccounts.admin.some(account => 
                account.username === username && account.password === adminPass
            );
            
        default:
            return false;
    }
}

// Success message
function showLoginSuccess(portalType) {
    let userInfo = '';
    
    switch(portalType) {
        case 'client':
            userInfo = "Welcome back! Redirecting to your client dashboard...";
            break;
        case 'employee':
            userInfo = "Employee access granted! Loading work portal...";
            break;
        case 'admin':
            userInfo = "Administrative access confirmed! Opening admin panel...";
            break;
    }
    
    // Create a nice success notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: #4CAF50;
        color: white;
        padding: 15px 20px;
        border-radius: 5px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
    `;
    notification.innerHTML = `
        <i class="fas fa-check-circle"></i> 
        <strong>Login Successful!</strong><br>
        ${userInfo}
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Error message
function showLoginError(portalType) {
    const errorMsg = portalType === 'general' ? 
        "Please select an option from the general portal." : 
        "Invalid credentials. Please try again.";
        
    // Create error notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: #f44336;
        color: white;
        padding: 15px 20px;
        border-radius: 5px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 3000;
        animation: slideIn 0.3s ease;
    `;
    notification.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i> 
        <strong>Login Failed</strong><br>
        ${errorMsg}
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Add CSS animations for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Mobile menu toggle
const mobileMenu = document.querySelector('.mobile-menu');
if (mobileMenu) {
    mobileMenu.addEventListener('click', function() {
        const nav = document.querySelector('nav ul');
        const authButtons = document.querySelector('.auth-buttons');
        
        if (nav && authButtons) {
            if (nav.style.display === 'flex') {
                nav.style.display = 'none';
                authButtons.style.display = 'none';
            } else {
                nav.style.display = 'flex';
                authButtons.style.display = 'flex';
            }
        }
    });
}

// Smooth scrolling for navigation links
document.querySelectorAll('nav a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all links
        document.querySelectorAll('nav a').forEach(link => {
            link.classList.remove('active');
        });
        
        // Add active class to clicked link
        this.classList.add('active');
        
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: 'smooth'
            });
        }
        
        // Close mobile menu if open
        if (window.innerWidth <= 768) {
            const nav = document.querySelector('nav ul');
            const authButtons = document.querySelector('.auth-buttons');
            if (nav) nav.style.display = 'none';
            if (authButtons) authButtons.style.display = 'none';
        }
    });
});

// Header scroll effect
window.addEventListener('scroll', function() {
    const header = document.querySelector('header');
    if (header) {
        if (window.scrollY > 100) {
            header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
            header.style.padding = '5px 0';
        } else {
            header.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
            header.style.padding = '15px 0';
        }
    }
});

// Demo credentials helper
function showDemoCredentials() {
    const credentialsHTML = `
        <div style="position: fixed; bottom: 20px; left: 20px; background: #333; color: white; padding: 15px; border-radius: 8px; z-index: 1000; max-width: 300px; font-size: 12px;">
            <strong>Demo Credentials:</strong><br>
            <strong>Client:</strong> client@klensecfarm.com / client123<br>
            <strong>Employee:</strong> EMP001 / employee123<br>
            <strong>Admin:</strong> admin / admin123<br>
            <button onclick="this.parentElement.remove()" style="margin-top: 10px; padding: 5px 10px; background: #ff9800; border: none; border-radius: 3px; color: white; cursor: pointer;">Close</button>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', credentialsHTML);
}

// Show demo credentials when page loads
window.addEventListener('load', showDemoCredentials);

console.log('Klensec Farm Portal with authentication loaded successfully!');